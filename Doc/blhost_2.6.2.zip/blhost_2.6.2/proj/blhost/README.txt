blhost 2.x read me
-------------------

Building

On Windows, open the .sln file in Microsoft Visual Studio. The solution contains projects
for each of the individual projects.

For Linux, run 'make all' from the gcc directory.

On Mac OS X, one way is run 'make all' from the mac-gcc directory. 
The other way is open the .xcodeproj project and build the "Everything" target.



