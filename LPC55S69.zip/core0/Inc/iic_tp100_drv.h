#ifndef __IIC_TP100_DRV_H
#define __IIC_TP100_DRV_H



float TMP101_ReadTemp(void);
void TMP101_Init(void);

#endif

