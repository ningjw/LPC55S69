#ifndef __IIC_TP100_DRV_H
#define __IIC_TP100_DRV_H



uint16_t TMP101_ReadTemp(void);
void TMP101_Init(void);

#endif

