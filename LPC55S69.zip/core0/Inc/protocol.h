#ifndef __PROTOCOL_H
#define __PROTOCOL_H



uint8_t* ParseProtocol(uint8_t *pMsg);

#endif
