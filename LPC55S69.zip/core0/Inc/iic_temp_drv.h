#ifndef __IIC_TEMP_DRV_H
#define __IIC_TEMP_DRV_H

float MXL_ReadEnvTemp(void);
float MXL_ReadObjTemp(void);

#endif
