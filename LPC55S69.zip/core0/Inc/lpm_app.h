#ifndef __LPM_APP_H
#define __LPM_APP_H



void SystemSleep(void);



#endif
