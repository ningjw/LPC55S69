
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'project' 
 * Target:  'core1' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "fsl_device_registers.h"

/*  ARM.FreeRTOS::RTOS:Config:FreeRTOS:10.2.0 */
#define RTE_RTOS_FreeRTOS_CONFIG        /* RTOS FreeRTOS Config for FreeRTOS API */
/*  ARM.FreeRTOS::RTOS:Core:Cortex-M:10.2.0 */
#define RTE_RTOS_FreeRTOS_CORE          /* RTOS FreeRTOS Core */
/*  ARM.FreeRTOS::RTOS:Coroutines:10.2.0 */
#define RTE_RTOS_FreeRTOS_COROUTINE     /* RTOS FreeRTOS Co-routines */
/*  ARM.FreeRTOS::RTOS:Event Groups:10.2.0 */
#define RTE_RTOS_FreeRTOS_EVENTGROUPS   /* RTOS FreeRTOS Event Groups */
/*  ARM.FreeRTOS::RTOS:Heap:Heap_4:10.2.0 */
#define RTE_RTOS_FreeRTOS_HEAP_4        /* RTOS FreeRTOS Heap 4 */
/*  ARM.FreeRTOS::RTOS:Message Buffer:10.2.0 */
#define RTE_RTOS_FreeRTOS_MESSAGE_BUFFER /* RTOS FreeRTOS Message Buffers */
/*  ARM.FreeRTOS::RTOS:Stream Buffer:10.2.0 */
#define RTE_RTOS_FreeRTOS_STREAM_BUFFER /* RTOS FreeRTOS Stream Buffers */
/*  NXP::Device:SDK Utilities:serial_manager_swo:1.0.0 */
#define SERIAL_PORT_TYPE_SWO 1
/*  NXP::Device:SDK Utilities:serial_manager_uart:1.0.0 */
#define SERIAL_PORT_TYPE_UART 1


#endif /* RTE_COMPONENTS_H */
